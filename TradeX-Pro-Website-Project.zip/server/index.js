import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 8787;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(cors());
app.use(express.json({ limit: '100kb' }));

const cache = new Map();
function cached(key, ttlMs, fn) {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.time < ttlMs) return Promise.resolve(entry.value);
  return fn().then(value => {
    cache.set(key, { time: Date.now(), value });
    return value;
  });
}
async function fetchJson(url, options = {}) {
  const res = await fetch(url, { ...options, headers: { 'accept': 'application/json', ...(options.headers || {}) } });
  if (!res.ok) {
    const err = new Error(`Market provider returned HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}
function sendProviderError(res, err) {
  const status = err.status === 429 ? 429 : 502;
  res.status(status).json({ error: err.status === 429 ? 'Provider rate limit reached. Please wait and retry.' : 'Market data provider is unavailable or the request is not supported.', detail: process.env.NODE_ENV === 'development' ? err.message : undefined });
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'TradeX Pro API', timestamp: new Date().toISOString() }));

// Crypto: CoinGecko public/demo API. Data is labeled with its provider timestamp.
app.get('/api/crypto', async (req, res) => {
  const ids = String(req.query.ids || 'bitcoin,ethereum,solana').split(',').slice(0, 30).map(x => x.trim()).filter(Boolean);
  const vs = String(req.query.vs || 'usd').toLowerCase();
  if (!/^[a-z]{2,8}$/.test(vs) || !ids.length || ids.some(x => !/^[a-z0-9-]{1,60}$/.test(x))) return res.status(400).json({ error: 'Invalid asset or quote currency.' });
  try {
    const data = await cached(`crypto:${ids.join(',')}:${vs}`, 30000, async () => {
      const key = process.env.COINGECKO_API_KEY;
      const headers = key ? { 'x-cg-demo-api-key': key } : {};
      const url = `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(ids.join(','))}&vs_currencies=${encodeURIComponent(vs)}&include_24hr_change=true&include_last_updated_at=true`;
      return fetchJson(url, { headers });
    });
    const assets = Object.entries(data).map(([id, values]) => ({
      id, symbol: id, category: 'crypto', price: values[vs] ?? null,
      change24h: values[`${vs}_24h_change`] ?? null,
      timestamp: values.last_updated_at ? new Date(values.last_updated_at * 1000).toISOString() : null,
      quote: vs.toUpperCase(), provider: 'CoinGecko', status: 'provider-data'
    }));
    res.json({ assets, fetchedAt: new Date().toISOString(), provider: 'CoinGecko', note: 'Provider data; freshness and availability depend on your API plan.' });
  } catch (e) { sendProviderError(res, e); }
});

// Stocks: Alpha Vantage GLOBAL_QUOTE. A key is required; free plans may be delayed/limited.
app.get('/api/stock', async (req, res) => {
  const symbol = String(req.query.symbol || 'AAPL').toUpperCase();
  if (!/^[A-Z0-9.^_-]{1,20}$/.test(symbol)) return res.status(400).json({ error: 'Invalid stock symbol.' });
  const key = process.env.ALPHAVANTAGE_API_KEY;
  if (!key) return res.status(503).json({ error: 'Stock data is not configured. Add ALPHAVANTAGE_API_KEY to the server .env file.' });
  try {
    const data = await cached(`stock:${symbol}`, 60000, async () => {
      const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${encodeURIComponent(key)}`;
      return fetchJson(url);
    });
    const q = data['Global Quote'];
    if (!q || !q['05. price']) {
      const message = data.Note || data.Information || data['Error Message'] || 'No quote returned. Check symbol, plan permissions, and API limits.';
      return res.status(502).json({ error: message });
    }
    res.json({ asset: { id: symbol, symbol, category: 'stock', name: symbol, price: Number(q['05. price']), change24h: Number(String(q['10. change percent'] || '').replace('%','')) || null, timestamp: q['07. latest trading day'] || null, quote: 'USD', provider: 'Alpha Vantage', status: 'provider-data' }, fetchedAt: new Date().toISOString(), note: 'Quote availability and delay depend on your Alpha Vantage plan.' });
  } catch (e) { sendProviderError(res, e); }
});

// Forex: Alpha Vantage CURRENCY_EXCHANGE_RATE. A key is required.
app.get('/api/forex', async (req, res) => {
  const from = String(req.query.from || 'USD').toUpperCase();
  const to = String(req.query.to || 'PKR').toUpperCase();
  if (!/^[A-Z]{3}$/.test(from) || !/^[A-Z]{3}$/.test(to)) return res.status(400).json({ error: 'Use three-letter currency codes.' });
  const key = process.env.ALPHAVANTAGE_API_KEY;
  if (!key) return res.status(503).json({ error: 'Forex data is not configured. Add ALPHAVANTAGE_API_KEY to the server .env file.' });
  try {
    const data = await cached(`forex:${from}:${to}`, 60000, async () => {
      const url = `https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=${from}&to_currency=${to}&apikey=${encodeURIComponent(key)}`;
      return fetchJson(url);
    });
    const q = data['Realtime Currency Exchange Rate'];
    if (!q || !q['5. Exchange Rate']) {
      const message = data.Note || data.Information || data['Error Message'] || 'No rate returned. Check provider limits and pair support.';
      return res.status(502).json({ error: message });
    }
    res.json({ asset: { id: `${from}${to}`, symbol: `${from}/${to}`, category: 'forex', price: Number(q['5. Exchange Rate']), change24h: null, timestamp: q['6. Last Refreshed'] || null, quote: to, provider: 'Alpha Vantage', status: 'provider-data' }, fetchedAt: new Date().toISOString(), note: 'Indicative provider rate; not an executable broker quote.' });
  } catch (e) { sendProviderError(res, e); }
});

// Serve production build when deployed as a single Node service.
const dist = path.resolve(__dirname, '../dist');
app.use(express.static(dist));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(dist, 'index.html'), err => { if (err) next(); });
});
app.listen(PORT, '0.0.0.0', () => console.log(`TradeX Pro server listening on ${PORT}`));