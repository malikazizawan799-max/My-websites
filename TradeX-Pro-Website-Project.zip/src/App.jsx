import React, { useEffect, useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, Bell, BriefcaseBusiness, ChartCandlestick, ChevronDown, CircleHelp, Clock3, Coins, Globe2, LayoutDashboard, Menu, Plus, RefreshCw, Search, Settings, ShieldCheck, Star, TrendingDown, TrendingUp, Wallet, X } from 'lucide-react';

const CRYPTO = [
  { id:'bitcoin', name:'Bitcoin', symbol:'BTC', category:'crypto', color:'#f7931a' },
  { id:'ethereum', name:'Ethereum', symbol:'ETH', category:'crypto', color:'#8b9cff' },
  { id:'solana', name:'Solana', symbol:'SOL', category:'crypto', color:'#8b5cf6' },
  { id:'ripple', name:'XRP', symbol:'XRP', category:'crypto', color:'#9ca3af' },
  { id:'binancecoin', name:'BNB', symbol:'BNB', category:'crypto', color:'#f3ba2f' },
];
const STOCKS = ['AAPL','MSFT','NVDA','AMZN','GOOGL','TSLA'].map(symbol=>({id:symbol,name:symbol,symbol,category:'stock'}));
const FOREX = [{id:'EURUSD',name:'Euro / US Dollar',symbol:'EUR/USD',category:'forex',from:'EUR',to:'USD'},{id:'GBPUSD',name:'British Pound / US Dollar',symbol:'GBP/USD',category:'forex',from:'GBP',to:'USD'},{id:'USDPKR',name:'US Dollar / Pakistani Rupee',symbol:'USD/PKR',category:'forex',from:'USD',to:'PKR'}];
const money = (n, currency='USD') => n == null || !Number.isFinite(Number(n)) ? '—' : new Intl.NumberFormat('en-US',{style:'currency',currency,maximumFractionDigits:Number(n)<1?6:2}).format(Number(n));
const pct = n => n == null || !Number.isFinite(Number(n)) ? '—' : `${Number(n)>0?'+':''}${Number(n).toFixed(2)}%`;
const time = t => t ? new Date(t).toLocaleString() : 'Timestamp not supplied by provider';

function IconButton({children,onClick,label}) { return <button className="icon-btn" onClick={onClick} aria-label={label}>{children}</button>; }

export default function App(){
  const [page,setPage]=useState('Dashboard');
  const [market,setMarket]=useState('All');
  const [search,setSearch]=useState('');
  const [prices,setPrices]=useState({});
  const [statuses,setStatuses]=useState({});
  const [lastRefresh,setLastRefresh]=useState(null);
  const [busy,setBusy]=useState(false);
  const [watchlist,setWatchlist]=useState(()=>JSON.parse(localStorage.getItem('tx-watchlist')||'["bitcoin","ethereum","AAPL","USDPKR"]'));
  const [holdings,setHoldings]=useState(()=>JSON.parse(localStorage.getItem('tx-holdings')||'[]'));
  const [alerts,setAlerts]=useState(()=>JSON.parse(localStorage.getItem('tx-alerts')||'[]'));
  const [showAdd,setShowAdd]=useState(false);
  const [showMenu,setShowMenu]=useState(false);
  const [notice,setNotice]=useState('');
  const [holdingForm,setHoldingForm]=useState({symbol:'BTC',quantity:'',entry:''});
  const [alertForm,setAlertForm]=useState({symbol:'bitcoin',target:'',direction:'above'});
  const [stockSymbol,setStockSymbol]=useState('AAPL');
  const [forexFrom,setForexFrom]=useState('USD');
  const [forexTo,setForexTo]=useState('PKR');

  useEffect(()=>localStorage.setItem('tx-watchlist',JSON.stringify(watchlist)),[watchlist]);
  useEffect(()=>localStorage.setItem('tx-holdings',JSON.stringify(holdings)),[holdings]);
  useEffect(()=>localStorage.setItem('tx-alerts',JSON.stringify(alerts)),[alerts]);

  async function loadAll(){
    setBusy(true); setNotice('');
    const nextStatus={...statuses}; const nextPrices={...prices};
    try {
      const r=await fetch('/api/crypto?ids='+CRYPTO.map(a=>a.id).join(',')+'&vs=usd');
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||'Crypto provider unavailable');
      d.assets.forEach(a=>{nextPrices[a.id]=a; nextStatus[a.id]={ok:a.price!=null,provider:a.provider,at:a.timestamp||d.fetchedAt,error:a.price==null?'Provider returned no price':null};});
    } catch(e){CRYPTO.forEach(a=>nextStatus[a.id]={ok:false,error:e.message});}
    for(const s of STOCKS){
      try {
        const r=await fetch('/api/stock?symbol='+s.symbol); const d=await r.json();
        if(!r.ok) throw new Error(d.error||'Stock provider unavailable');
        nextPrices[s.id]=d.asset; nextStatus[s.id]={ok:true,provider:d.asset.provider,at:d.asset.timestamp||d.fetchedAt};
      } catch(e){nextStatus[s.id]={ok:false,error:e.message};}
    }
    for(const f of FOREX){
      try {
        const r=await fetch('/api/forex?from='+f.from+'&to='+f.to); const d=await r.json();
        if(!r.ok) throw new Error(d.error||'Forex provider unavailable');
        nextPrices[f.id]=d.asset; nextStatus[f.id]={ok:true,provider:d.asset.provider,at:d.asset.timestamp||d.fetchedAt};
      } catch(e){nextStatus[f.id]={ok:false,error:e.message};}
    }
    setPrices(nextPrices); setStatuses(nextStatus); setLastRefresh(new Date().toISOString()); setBusy(false);
    const cryptoReady=CRYPTO.some(a=>nextPrices[a.id]?.price!=null);
    if(!cryptoReady) setNotice('Market data is not connected yet. Crypto API access may be limited, and stocks/forex need an Alpha Vantage key. See Setup Guide below.');
  }
  useEffect(()=>{loadAll();},[]); // initial refresh only; manual refresh button avoids surprise provider calls
  const allAssets=[...CRYPTO,...STOCKS,...FOREX];
  const visibleAssets=useMemo(()=>allAssets.filter(a=>(market==='All'||a.category===market.toLowerCase()) && `${a.name} ${a.symbol}`.toLowerCase().includes(search.toLowerCase())),[market,search]);
  const watchAssets=allAssets.filter(a=>watchlist.includes(a.id));
  const totalValue=holdings.reduce((sum,h)=>sum+(Number(h.quantity)||0)*(prices[h.assetId]?.price||0),0);
  const totalCost=holdings.reduce((sum,h)=>sum+(Number(h.quantity)||0)*(Number(h.entry)||0),0);
  const pnl=totalValue-totalCost;
  const chartData=Array.from({length:12},(_,i)=>({time:['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','Now'][i],value:null}));
  const hasCrypto=CRYPTO.some(a=>prices[a.id]?.price!=null);
  const menuItems=[['Dashboard',LayoutDashboard],['Markets',Globe2],['Watchlist',Star],['Portfolio',Wallet],['Price Alerts',Bell],['Setup Guide',Settings]];
  const currentPage=page==='Markets'?'All':page;
  function toggleWatch(id){setWatchlist(w=>w.includes(id)?w.filter(x=>x!==id):[...w,id]);}
  function addHolding(e){e.preventDefault();const a=allAssets.find(x=>x.symbol.toLowerCase()===holdingForm.symbol.trim().toLowerCase()||x.id.toLowerCase()===holdingForm.symbol.trim().toLowerCase());if(!a||Number(holdingForm.quantity)<=0||Number(holdingForm.entry)<0){setNotice('Choose a listed asset and enter a valid quantity and entry price.');return;}setHoldings(h=>[...h,{id:crypto.randomUUID(),assetId:a.id,symbol:a.symbol,quantity:Number(holdingForm.quantity),entry:Number(holdingForm.entry)}]);setShowAdd(false);setHoldingForm({symbol:'BTC',quantity:'',entry:''});}
  function addAlert(e){e.preventDefault();const a=allAssets.find(x=>x.id===alertForm.symbol);if(!a||Number(alertForm.target)<=0){setNotice('Choose an asset and enter a target above zero.');return;}setAlerts(old=>[...old,{id:crypto.randomUUID(),assetId:a.id,symbol:a.symbol,target:Number(alertForm.target),direction:alertForm.direction,created:new Date().toISOString()}]);setNotice('Alert saved on this device. Alerts are checked while this app is open; background delivery is not enabled.');}
  function downloadCSV(){const rows=[['Symbol','Quantity','Entry Price','Latest Available Price','Estimated Value','Unrealized P/L'],...holdings.map(h=>[h.symbol,h.quantity,h.entry,prices[h.assetId]?.price??'',(h.quantity*(prices[h.assetId]?.price||0)).toFixed(2),(h.quantity*((prices[h.assetId]?.price||0)-h.entry)).toFixed(2)])];const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));const a=document.createElement('a');a.href=url;a.download='tradex-holdings.csv';a.click();URL.revokeObjectURL(url);}
  return <div className="app-shell">
    <aside className={`sidebar ${showMenu?'mobile-open':''}`}>
      <div className="brand"><div className="brand-mark"><Activity size={22}/></div><div><b>TradeX <span>Pro</span></b><small>MARKET TERMINAL</small></div><IconButton label="Close menu" onClick={()=>setShowMenu(false)}><X size={18}/></IconButton></div>
      <div className="nav-label">WORKSPACE</div>
      {menuItems.map(([label,Icon])=><button key={label} className={`nav-item ${page===label?'active':''}`} onClick={()=>{setPage(label);setShowMenu(false);}}><Icon size={18}/><span>{label}</span>{label==='Price Alerts'&&alerts.length>0&&<em>{alerts.length}</em>}</button>)}
      <div className="sidebar-bottom"><div className="security-note"><ShieldCheck size={17}/><div><b>Tracking mode</b><span>No broker connected</span></div></div><div className="version">TRADEX PRO · STARTER BUILD</div></div>
    </aside>
    {showMenu&&<button className="scrim" onClick={()=>setShowMenu(false)} aria-label="Close menu"/>}
    <main className="main">
      <header className="topbar"><div className="mobile-brand"><IconButton label="Open menu" onClick={()=>setShowMenu(true)}><Menu/></IconButton><b>TradeX <span>Pro</span></b></div><div className="breadcrumb">Workspace <span>/</span> {page}</div><div className="top-actions"><div className="data-pill"><span className={`status-dot ${hasCrypto?'':'off'}`}></span>{hasCrypto?'Provider data available':'Data setup needed'}</div><IconButton label="Refresh market data" onClick={loadAll}><RefreshCw className={busy?'spin':''} size={18}/></IconButton></div></header>
      <div className="content">
        <div className="welcome-row"><div><div className="eyebrow">MULTI-MARKET OVERVIEW <span className="live-dot"></span></div><h1>{page==='Dashboard'?'Market dashboard':page}</h1><p className="muted">Track market data from configured providers. No real trades are executed.</p></div><button className="primary-btn" onClick={loadAll} disabled={busy}><RefreshCw size={16} className={busy?'spin':''}/>{busy?'Refreshing…':'Refresh data'}</button></div>
        {notice&&<div className="notice"><CircleHelp size={18}/><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Dismiss notice"><X size={16}/></button></div>}
        {page==='Dashboard'&&<Dashboard prices={prices} statuses={statuses} watchAssets={watchAssets} holdings={holdings} totalValue={totalValue} pnl={pnl} lastRefresh={lastRefresh} setPage={setPage} toggleWatch={toggleWatch} watchlist={watchlist} assets={allAssets}/>}
        {page==='Markets'&&<><div className="filter-row"><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search assets or symbols…"/></div><div className="filter-tabs">{['All','Crypto','Forex','Stock'].map(m=><button key={m} className={market===m?'selected':''} onClick={()=>setMarket(m)}>{m}</button>)}</div></div><AssetTable assets={visibleAssets} prices={prices} statuses={statuses} watchlist={watchlist} toggleWatch={toggleWatch}/></>}
        {page==='Watchlist'&&<><div className="section-heading"><div><h2>Your watchlist</h2><p>Saved on this device. Prices appear only when provider data is available.</p></div><button className="secondary-btn" onClick={()=>setPage('Markets')}><Plus size={16}/> Add assets</button></div><AssetTable assets={watchAssets} prices={prices} statuses={statuses} watchlist={watchlist} toggleWatch={toggleWatch}/></>}
        {page==='Portfolio'&&<><div className="stats-grid"><Stat title="Estimated market value" value={money(totalValue)} icon={Wallet} hint="Based on available provider prices"/><Stat title="Recorded cost basis" value={money(totalCost)} icon={BriefcaseBusiness} hint="From entries you added"/><Stat title="Unrealized P/L estimate" value={money(pnl)} icon={pnl>=0?TrendingUp:TrendingDown} hint="Not broker-reported" positive={pnl>=0}/></div><div className="section-heading"><div><h2>Holdings</h2><p>Manually entered holdings; this is not connected to a brokerage account.</p></div><div className="inline-actions"><button className="secondary-btn" onClick={downloadCSV}>Export CSV</button><button className="primary-btn" onClick={()=>setShowAdd(true)}><Plus size={16}/> Add holding</button></div></div>{showAdd&&<form className="form-card" onSubmit={addHolding}><label>Asset symbol or ID<input required value={holdingForm.symbol} onChange={e=>setHoldingForm({...holdingForm,symbol:e.target.value})} placeholder="BTC, AAPL, USDPKR"/></label><label>Quantity<input required type="number" min="0.00000001" step="any" value={holdingForm.quantity} onChange={e=>setHoldingForm({...holdingForm,quantity:e.target.value})}/></label><label>Entry price (USD for crypto/stocks; quote currency for forex)<input required type="number" min="0" step="any" value={holdingForm.entry} onChange={e=>setHoldingForm({...holdingForm,entry:e.target.value})}/></label><button className="primary-btn" type="submit">Save holding</button><button className="secondary-btn" type="button" onClick={()=>setShowAdd(false)}>Cancel</button></form>}<HoldingsTable holdings={holdings} prices={prices} onRemove={id=>setHoldings(h=>h.filter(x=>x.id!==id))}/></>}
        {page==='Price Alerts'&&<><div className="section-heading"><div><h2>Price alerts</h2><p>Alerts are checked in this browser session only. Background push delivery is not configured.</p></div></div><form className="form-card alert-form" onSubmit={addAlert}><label>Asset<select value={alertForm.symbol} onChange={e=>setAlertForm({...alertForm,symbol:e.target.value})}>{allAssets.map(a=><option key={a.id} value={a.id}>{a.symbol} — {a.name}</option>)}</select></label><label>Condition<select value={alertForm.direction} onChange={e=>setAlertForm({...alertForm,direction:e.target.value})}><option value="above">Price rises above</option><option value="below">Price falls below</option></select></label><label>Target price<input required type="number" min="0.00000001" step="any" value={alertForm.target} onChange={e=>setAlertForm({...alertForm,target:e.target.value})}/></label><button className="primary-btn" type="submit"><Bell size={16}/> Create alert</button></form><div className="alert-list">{alerts.map(a=>{const p=prices[a.assetId]?.price;const hit=p!=null&&(a.direction==='above'?p>=a.target:p<=a.target);return <div className="alert-row" key={a.id}><div className="asset-icon">{a.symbol.slice(0,2)}</div><div className="alert-info"><b>{a.symbol} {a.direction==='above'?'above':'below'} {a.target}</b><span>{p==null?'Waiting for provider data':hit?'Target condition met':'Current: '+p}</span></div><span className={`badge ${hit?'good':''}`}>{hit?'Triggered':'Watching'}</span><IconButton label="Delete alert" onClick={()=>setAlerts(old=>old.filter(x=>x.id!==a.id))}><X size={17}/></IconButton></div>})}{alerts.length===0&&<Empty title="No alerts yet" text="Create an alert to monitor a price threshold while this app is open."/ >}</div></>}
        {page==='Setup Guide'&&<SetupGuide/>}
        <footer className="footer"><div><b>TradeX Pro</b><span>Market tracking starter project</span></div><div>Market data may be delayed or unavailable. Not investment advice.</div></footer>
      </div>
    </main>
  </div>;
}

function Dashboard({prices,statuses,watchAssets,holdings,totalValue,pnl,lastRefresh,setPage,toggleWatch,watchlist,assets}){
 const crypto=[...CRYPTO].map(a=>({...a,...prices[a.id]}));
 return <><div className="stats-grid"><Stat title="Tracked crypto market" value={crypto.some(a=>a.price!=null)?money(crypto.find(a=>a.id==='bitcoin')?.price):'Not connected'} icon={Coins} hint="BTC reference price, if available"/><Stat title="Watchlist assets" value={watchAssets.length} icon={Star} hint="Saved on this device"/><Stat title="Recorded holdings value" value={money(totalValue)} icon={Wallet} hint="Estimated from available prices"/><Stat title="Portfolio P/L estimate" value={money(pnl)} icon={pnl>=0?TrendingUp:TrendingDown} hint="Not broker-reported" positive={pnl>=0}/></div>
 <div className="dashboard-grid"><section className="panel chart-panel"><div className="panel-head"><div><h2>Market pulse</h2><p>Chart shown only when real historical series is configured.</p></div><span className="badge">Overview</span></div><div className="chart-placeholder"><div className="chart-symbol"><ChartCandlestick size={25}/></div><b>Connect historical market data</b><span>This starter does not fabricate chart points. Configure a provider endpoint for OHLC/history to enable real candlesticks.</span><button className="text-btn" onClick={()=>setPage('Setup Guide')}>View setup guide <ChevronDown size={15}/></button></div><div className="chart-footer"><span><Clock3 size={14}/> Last refresh: {lastRefresh?new Date(lastRefresh).toLocaleTimeString():'Not yet refreshed'}</span><span><span className="status-dot off"></span>Historical series not configured</span></div></section>
 <section className="panel movers-panel"><div className="panel-head"><div><h2>Popular assets</h2><p>Latest available provider quotes</p></div><button className="text-btn" onClick={()=>setPage('Markets')}>All markets</button></div>{crypto.slice(0,4).map(a=><AssetMini key={a.id} asset={a} price={prices[a.id]} status={statuses[a.id]} watchlist={watchlist} toggleWatch={toggleWatch}/> )}</section></div>
 <section className="panel"><div className="panel-head"><div><h2>Market watch</h2><p>Crypto, forex and stock symbols</p></div><button className="secondary-btn" onClick={()=>setPage('Markets')}>Explore markets</button></div><AssetTable assets={assets.slice(0,8)} prices={prices} statuses={statuses} watchlist={watchlist} toggleWatch={toggleWatch}/></section>
 <div className="disclaimer"><ShieldCheck size={18}/><div><b>Tracking, not brokerage trading</b><span>No funds are deposited, no orders are sent to a broker, and no investment returns are guaranteed. Connect a licensed broker only after a separate secure integration and compliance review.</span></div></div></>;
}
function Stat({title,value,icon:Icon,hint,positive}){return <div className="stat-card"><div className="stat-top"><span>{title}</span><div className="stat-icon"><Icon size={18}/></div></div><div className="stat-value">{value}</div><div className={`stat-hint ${positive===undefined?'':positive?'green':'red'}`}>{hint}</div></div>}
function AssetMini({asset,price,status,watchlist,toggleWatch}){return <div className="asset-mini"><div className="asset-icon" style={{background:asset.color||'#243047'}}>{asset.symbol.slice(0,2)}</div><div className="asset-mini-name"><b>{asset.name}</b><span>{asset.symbol}</span></div><div className="asset-mini-price"><b>{price?.price!=null?money(price.price,price.quote||'USD'):'—'}</b><span className={price?.change24h>=0?'green':'red'}>{pct(price?.change24h)}</span></div><IconButton label="Toggle watchlist" onClick={()=>toggleWatch(asset.id)}><Star size={16} fill={watchlist.includes(asset.id)?'currentColor':'none'}/></IconButton>{status?.error&&<div className="tiny-error" title={status.error}>Data unavailable</div>}</div>}
function AssetTable({assets,prices,statuses,watchlist,toggleWatch}){return <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Category</th><th>Latest price</th><th>24h change</th><th>Source / status</th><th></th></tr></thead><tbody>{assets.map(a=>{const p=prices[a.id];const s=statuses[a.id];return <tr key={a.id}><td><div className="table-asset"><div className="asset-icon" style={{background:a.color||'#243047'}}>{a.symbol.slice(0,2)}</div><div><b>{a.name}</b><span>{a.symbol}</span></div></div></td><td><span className="category">{a.category}</span></td><td className="price-cell">{p?.price!=null?money(p.price,p.quote||'USD'):'—'}{p?.timestamp&&<small>{time(p.timestamp)}</small>}</td><td className={p?.change24h>=0?'green':'red'}>{pct(p?.change24h)}</td><td>{p?.provider?<><span className="source">{p.provider}</span><small className="data-state">Provider response</small></>:<span className="unavailable" title={s?.error||'Not configured'}>Not configured</span>}{s?.error&&<small className="error-detail">{s.error}</small>}</td><td><IconButton label="Toggle watchlist" onClick={()=>toggleWatch(a.id)}><Star size={16} fill={watchlist.includes(a.id)?'currentColor':'none'}/></IconButton></td></tr>})}{assets.length===0&&<tr><td colSpan="6"><Empty title="No matching assets" text="Try a different search or market filter."/></td></tr>}</tbody></table></div>}
function HoldingsTable({holdings,prices,onRemove}){return <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Quantity</th><th>Entry price</th><th>Latest price</th><th>Estimated value</th><th>Unrealized P/L</th><th></th></tr></thead><tbody>{holdings.map(h=>{const p=prices[h.assetId]?.price;const value=h.quantity*(p||0);const pl=h.quantity*((p||0)-h.entry);return <tr key={h.id}><td><b>{h.symbol}</b></td><td>{h.quantity}</td><td>{money(h.entry)}</td><td>{p!=null?money(p,prices[h.assetId]?.quote||'USD'):'—'}</td><td>{p!=null?money(value):'—'}</td><td className={pl>=0?'green':'red'}>{p!=null?money(pl):'—'}</td><td><IconButton label="Remove holding" onClick={()=>onRemove(h.id)}><X size={16}/></IconButton></td></tr>})}{holdings.length===0&&<tr><td colSpan="7"><Empty title="No holdings recorded" text="Add your own holdings to estimate value from available market data."/></td></tr>}</tbody></table></div>}
function Empty({title,text}){return <div className="empty"><b>{title}</b><span>{text}</span></div>}
function SetupGuide(){return <div className="setup-layout"><section className="panel setup-card"><div className="setup-number">01</div><h2>Start the app</h2><p>Install Node.js on a computer or cloud development environment, extract the project ZIP, and run:</p><pre>npm install{'\n'}cp .env.example .env{'\n'}npm run dev</pre><p>Open the local Vite URL shown in your terminal. On Android alone, use a browser-based development environment that supports Node.js and terminal commands.</p></section><section className="panel setup-card"><div className="setup-number">02</div><h2>Enable crypto prices</h2><p>The server attempts to fetch BTC, ETH, SOL and other assets from CoinGecko. If your plan requires a key, add it to the server-side <code>.env</code> file:</p><pre>COINGECKO_API_KEY=your_key_here</pre><p>Restart the server after editing environment variables. Never put secret keys in React code.</p><a href="https://www.coingecko.com/en/api" target="_blank" rel="noreferrer">Get CoinGecko API access ↗</a></section><section className="panel setup-card"><div className="setup-number">03</div><h2>Enable stocks and forex</h2><p>Create an Alpha Vantage API key, then add it to the server-side <code>.env</code> file:</p><pre>ALPHAVANTAGE_API_KEY=your_key_here</pre><p>Free-tier endpoints may be limited, delayed, or unavailable for some symbols. This app reports missing data rather than inventing prices.</p><a href="https://www.alphavantage.co/" target="_blank" rel="noreferrer">Alpha Vantage API ↗</a></section><section className="panel setup-card"><div className="setup-number">04</div><h2>Deploy the website</h2><p>Use a Node.js host that supports environment variables and a persistent Express server. Build with <code>npm run build</code> and start with <code>npm start</code>. Set your secret keys in the host's environment settings.</p><p>For a production release, add authentication, database security rules, rate limiting, monitoring, and HTTPS before storing user accounts or private data.</p></section><section className="panel setup-card warning-card"><ShieldCheck size={22}/><div><h2>Real-money trading is not enabled</h2><p>This starter provides market tracking and a manual portfolio tracker. A real trading platform needs a licensed broker API, server-side order handling, secure authentication, risk controls, audit logs, and legal/compliance review. Do not collect deposits or broker passwords in this starter.</p></div></section></div>}
