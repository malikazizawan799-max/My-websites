# TradeX Pro — Multi-market tracking starter

A responsive React + Vite + Express starter for crypto, stock, and forex market tracking, watchlists, manually recorded holdings, CSV export, and browser-session price alerts.

**Important:** This is not a real-money trading system. It does not place broker orders, accept deposits, or connect to brokerage accounts. A real broker integration requires a licensed provider, secure backend order handling, risk controls, audit logging, and compliance review.

## Requirements

- Node.js 20 or newer recommended
- npm
- Market data provider accounts as needed

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

The Vite frontend runs on the local URL printed by Vite. The Express API runs on port 8787. Vite proxies `/api` requests to Express.

On Windows, create `.env` by copying `.env.example` manually if `cp` is unavailable.

## Configure market data

### Crypto
The server calls CoinGecko's simple price endpoint for BTC, ETH, SOL, XRP, and BNB. Depending on current CoinGecko requirements and your plan, add a key to `.env`:

```env
COINGECKO_API_KEY=your_key_here
```

No live prices are hardcoded in the app. If the provider fails, the UI shows unavailable status. Provider response timestamps are used where supplied; provider latency and plan limits still apply.

### Stocks and Forex
The stock and forex endpoints use Alpha Vantage. Add your key to the server-side `.env`:

```env
ALPHAVANTAGE_API_KEY=your_key_here
```

The free plan may have request limits and may not offer real-time exchange data for every symbol. The app will show an error/unconfigured state instead of fake prices. Check your provider plan and licensing terms.

## Production build

```bash
npm run build
npm start
```

Set `PORT` and provider keys in the hosting platform's server environment settings. Deploy to a Node.js host that can run the Express server and serve the `dist` folder. Use HTTPS.

## Android usage

You can preview the responsive site in an Android browser. For development from Android, use a cloud IDE that provides Node.js, terminal access, and port forwarding. Installing a PWA is supported by compatible browsers once the site is deployed over HTTPS. A native APK is not included.

## Included functionality

- Responsive dark UI and navigation
- Crypto market quotes from CoinGecko endpoint
- Stock quotes from Alpha Vantage when configured
- Forex rates from Alpha Vantage when configured
- Market search and filters
- Local watchlist
- Local manual portfolio tracker and CSV export
- Browser-session price threshold alerts
- Data source/error status labels
- PWA manifest and service worker shell caching

## Not included yet

- Real brokerage orders or deposits
- User login / cloud sync
- Push notifications while the app is closed
- Historical OHLC chart API integration (the dashboard explicitly indicates this is not configured)
- Automated testing suite
- Financial advice, trade recommendations, or profit guarantees

## Production hardening checklist

Before handling user accounts or private information:
- Add authentication and database access rules
- Add rate limiting, monitoring, request validation, and abuse protection
- Review provider licenses, quotas, and attribution
- Add a dedicated historical-data adapter for charts
- Add unit and integration tests
- Perform a security review and legal/compliance review
- Do not store brokerage credentials; use official OAuth/API flows from a supported broker
